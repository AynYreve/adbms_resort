<%-- 
    Document   : process_booking
    Created on : Jun 7, 2026, 8:16:39 AM
    Author     : Julian Edriel
--%>
<%@ page import="java.sql.*" %>

<%
String fullname = (String) session.getAttribute("fullname");
String email = (String) session.getAttribute("email");

String roomType = request.getParameter("roomType");
String adultCount = request.getParameter("adultCount");
String childrenCount = request.getParameter("childrenCount");

Connection conn = null;
PreparedStatement pst = null;

try {

    Class.forName("com.mysql.cj.jdbc.Driver");

    conn = DriverManager.getConnection(
        "jdbc:mysql://127.0.0.1:3306/olivia_db",
        "root",
        "39GroundControlToMajorTom39"
    );

    out.println(email);
    String sql = "INSERT INTO booking(guestname, email, room_type, adult_count, children_count) VALUES (?, ?, ?, ?, ?)";

    pst = conn.prepareStatement(sql);

    pst.setString(1, fullname);
    pst.setString(2, email);
    pst.setString(3, roomType);
    pst.setInt(4, Integer.parseInt(adultCount));
    pst.setInt(5, Integer.parseInt(childrenCount));

    pst.executeUpdate();

    out.println("<script>");
    out.println("alert('Reservation Successful!');");
    out.println("window.location='/OliviaEvent/home.jsp';");
    out.println("</script>");

}
catch(Exception e) {
    out.println(e);
}
finally {

    if(pst != null) pst.close();
    if(conn != null) conn.close();
}
%>


<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Hello World!</h1>
    </body>
</html>
